//
//  HomeViewController.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var profilePicButton: UIButton!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var editImageButton: UIButton!
    @IBOutlet weak var subHeaderLabel: UILabel!
    @IBOutlet weak var dataTableView: UITableView!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var pdfButton: UIButton!
    @IBOutlet weak var themeButton: UIButton!
    @IBOutlet weak var darkThemeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        allUIElements()
        menuView.isHidden = true
//        dataTableView.delegate = self
//        dataTableView.dataSource = self
    }
    
    func allUIElements() {
        viewUI()
        labelUI()
        buttonUI()
        imageViewUI()
    }
    
    func viewUI() {
        headerView.backgroundColor = .blue
        menuView.backgroundColor = .systemIndigo
    }
    
    func labelUI() {
        headerLabel.text = "Dashboard"
    }
    
    func buttonUI() {
        menuButton.layer.cornerRadius = menuButton.frame.height / 2
        menuButton.backgroundColor = .white
        
        profilePicButton.layer.cornerRadius = profilePicButton.frame.height / 2
        
        pdfButton.setTitle("PDF File", for: .normal)
        pdfButton.setTitleColor(.white, for: .normal)
        pdfButton.setImage(UIImage(systemName: "chevron.right"), for: .normal)

        themeButton.setTitle("Light Theme", for: .normal)
        themeButton.setTitleColor(.white, for: .normal)
        themeButton.setImage(UIImage(systemName: "chevron.right"), for: .normal)
        
        darkThemeButton.setTitle("Dark Theme", for: .normal)
        darkThemeButton.setTitleColor(.white, for: .normal)
        darkThemeButton.setImage(UIImage(systemName: "chevron.right"), for: .normal)

    }
    
    func imageViewUI() {
       
    }

    @IBAction func menuButtonAction(_ sender: UIButton) {
        menuView.isHidden = false
    }
    
    @IBAction func profileButtonAction(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let profileVC = storyBoard.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        profileVC.profilePicImageView.image = self.profileImageView.image
        
        profileVC.onprofileImagePicked = { [weak self] image in
            self?.profileImageView.image = image
            UserManager.shared.profileImage = image
        }
        self.navigationController?.pushViewController(profileVC, animated: true)
    }
    
    @IBAction func editProfileImageAction(_ sender: UIButton) {
        
    }
    
    @IBAction func pdfButtonAction(_ sender: UIButton) {
        let navController = UINavigationController(rootViewController: PDFViewerViewController())
        present(navController, animated: true, completion: nil)
    }
    
    @IBAction func themeButtonAction(_ sender: UIButton) {
        
    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        <#code#>
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        <#code#>
//    }
    
    
    
    
}
