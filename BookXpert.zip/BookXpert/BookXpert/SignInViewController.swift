//
//  SignInViewController.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import UIKit
import FirebaseCore
import GoogleSignIn
import FirebaseAuth


class SignInViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var googleSignInButton: UIButton!
    
    let coredataViewModel = UserViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemMint
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            fatalError("No Client ID found in Firebase config")
        }
        GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientID)
        allUIElements()
    }
    
    func allUIElements() {
        labelUI()
        buttonUI()
    }
    
    func labelUI() {
        welcomeLabel.text = "Welcome to BookXpert"
        welcomeLabel.textColor = .white
        welcomeLabel.font = .boldSystemFont(ofSize: 28)
    }
    
    func buttonUI() {
        googleSignInButton.setTitle("Login With Google", for: .normal)
        googleSignInButton.titleLabel?.font = .boldSystemFont(ofSize: 18)
        googleSignInButton.setTitleColor(.white, for: .normal)
        googleSignInButton.backgroundColor = .systemBlue
        googleSignInButton.layer.cornerRadius = 5
    }

    @IBAction func googleSignInAction(_ sender: Any) {   
        guard let presentingVC = self.view.window?.rootViewController else {
            print("No rootViewController")
            return
        }
        
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingVC) { result, error in
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }
            
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                print("Missing token info")
                return
            }
            
            let accessToken = user.accessToken.tokenString
            
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
            
            Auth.auth().signIn(with: credential) { authResult, error in
                if let error = error {
                    print("Firebase sign-in failed: \(error.localizedDescription)")
                    return
                }
                
                if let user = authResult?.user {
                    print("Signed in: \(user.email ?? "")")
                    self.coredataViewModel.saveUser(uid: "", email: user.email ?? "") { success in
                        
                        if success {
                            print("saved successfully!!!")
                            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                            let homeVC = storyBoard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                            self.navigationController?.pushViewController(homeVC, animated: true)
                        } else {
                            print("Failed!!!")
                        }
                    }
                }
            }
        }
    }
}
