//
//  PDFViewerViewController.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//


import UIKit
import PDFKit

class PDFViewerViewController: UIViewController {

    let pdfView = PDFView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "PDF Viewer"
        
        view.backgroundColor = .white
        
        let backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backTapped))
        navigationItem.leftBarButtonItem = backButton

        // Configure PDFView
        pdfView.translatesAutoresizingMaskIntoConstraints = false
        pdfView.autoScales = true
        view.addSubview(pdfView)
        
        NSLayoutConstraint.activate([
            pdfView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pdfView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pdfView.topAnchor.constraint(equalTo: view.topAnchor),
            pdfView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Load PDF from web URL
        if let url = URL(string: "https://fssservices.bookxpert.co/GeneratedPDF/Companies/nadc/2024-2025/BalanceSheet.pdf") {
            fetchPDF(from: url)
        } else {
            print("Invalid PDF URL")
        }
    }

    func fetchPDF(from url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data, let document = PDFDocument(data: data) {
                DispatchQueue.main.async {
                    self.pdfView.document = document
                }
            } else {
                print("Failed to load PDF: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        task.resume()
    }
    
    @objc func backTapped() {
        dismiss(animated: true, completion: nil)
    }
}
