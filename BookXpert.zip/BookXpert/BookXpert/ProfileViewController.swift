//
//  ProfileViewController.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var profilePicImageView: UIImageView!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var galleryButton: UIButton!
    
    var onprofileImagePicked: ((UIImage) -> Void)?
    var profileImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        allUIElements()
        view.backgroundColor = .black
        profilePicImageView.image = UserManager.shared.profileImage
    }
    
    func allUIElements() {
        buttonUI()
        imageViewUI()
    }
    
    func buttonUI() {
        backButton.setTitle("Back", for: .normal)
        backButton.layer.cornerRadius = backButton.frame.height / 2
        backButton.backgroundColor = .darkGray
        
        cameraButton.backgroundColor = .darkGray
        cameraButton.layer.cornerRadius = cameraButton.frame.height / 2
        
        galleryButton.backgroundColor = .darkGray
        galleryButton.layer.cornerRadius = galleryButton.frame.height / 2
    }
    
    func imageViewUI() {
        profilePicImageView.backgroundColor = .darkGray
        profilePicImageView.layer.cornerRadius = profilePicImageView.frame.height / 2
        profilePicImageView.image = profileImage
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var selectedImage: UIImage?

        if let editedImage = info[.editedImage] as? UIImage {
            selectedImage = editedImage
        } else if let originalImage = info[.originalImage] as? UIImage {
            selectedImage = originalImage
        }
        
        if let image = selectedImage {
            profilePicImageView.image = image
            profilePicImageView.contentMode = .scaleAspectFill
            onprofileImagePicked?(image)
        }
        
        dismiss(animated: true)
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func cameraButtonAction(_ sender: UIButton) {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print("Camera not available")
            return
        }
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    @IBAction func galleryButtonAction(_ sender: UIButton) {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            print("Gallery not available")
            return
        }
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
}
