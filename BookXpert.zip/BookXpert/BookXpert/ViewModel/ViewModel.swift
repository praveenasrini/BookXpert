//
//  ViewModel.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import UIKit
import CoreData

class UserViewModel {

    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var users: [UserEntity] = []

    // MARK: - Save
    func saveUser(uid: String, email: String, completion: @escaping (Bool) -> Void) {
        let user = UserEntity(context: context)
        user.userid = uid
//        user.name = name
        user.emailid = email
//        user.profileImage = profileImage

        do {
            try context.save()
            completion(true)
        } catch {
            print("Save failed: \(error)")
            completion(false)
        }
    }

    // MARK: - Fetch
    func fetchUsers(completion: @escaping ([UserEntity]) -> Void) {
        let request: NSFetchRequest<UserEntity> = UserEntity.fetchRequest()
        do {
            users = try context.fetch(request)
            completion(users)
        } catch {
            print("Fetch failed: \(error)")
            completion([])
        }
    }

    // MARK: - Update
    func updateUser(uid: String, newName: String?, newEmail: String?, completion: @escaping (Bool) -> Void) {
        let request: NSFetchRequest<UserEntity> = UserEntity.fetchRequest()
        request.predicate = NSPredicate(format: "uid == %@", uid)

        do {
            if let user = try context.fetch(request).first {
//                if let name = newName { user.name = name }
                if let email = newEmail { user.emailid = email }

                try context.save()
                completion(true)
            } else {
                completion(false)
            }
        } catch {
            print("Update failed: \(error)")
            completion(false)
        }
    }

    // MARK: - Delete
    func deleteUser(uid: String, completion: @escaping (Bool) -> Void) {
        let request: NSFetchRequest<UserEntity> = UserEntity.fetchRequest()
        request.predicate = NSPredicate(format: "uid == %@", uid)

        do {
            if let user = try context.fetch(request).first {
                context.delete(user)
                try context.save()
                completion(true)
            } else {
                completion(false)
            }
        } catch {
            print("Delete failed: \(error)")
            completion(false)
        }
    }
}


