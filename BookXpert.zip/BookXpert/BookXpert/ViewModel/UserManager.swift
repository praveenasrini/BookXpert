//
//  UserManager.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import Foundation
import UIKit

class UserManager {
    static let shared = UserManager()
    var profileImage: UIImage?
}
