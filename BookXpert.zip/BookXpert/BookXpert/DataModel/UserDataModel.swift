//
//  UserDataModel.swift
//  BookXpert
//
//  Created by Praveena Srinivasan on 29/04/25.
//

import Foundation

struct UserInfo {
    let userID: String?
    var emailID: String?
    var passWord: String?
}
